
import React from 'react';
import type { Dialogue } from '../types';
import { useLanguage } from '../App';
import { translations } from '../gameData';

interface DialogueBoxProps {
  dialogue: Dialogue;
  typedText: string;
}

const DialogueBox: React.FC<DialogueBoxProps> = ({ dialogue, typedText }) => {
  const { language } = useLanguage();
  if (!dialogue) return null;

  const isNarrator = dialogue.character === 'Narrator';
  const characterName = translations[language].characters[dialogue.character as keyof typeof translations[typeof language]['characters']] || dialogue.character;


  return (
    <div className="absolute bottom-0 left-0 right-0 p-8 cursor-pointer">
      <div className="bg-black bg-opacity-75 rounded-lg p-6 text-white max-w-5xl mx-auto border-2 border-purple-500/50 shadow-lg shadow-purple-900/50">
        {!isNarrator && (
          <h2 className="text-2xl font-bold mb-2 text-purple-300">
            {characterName}
          </h2>
        )}
        <p className={`text-xl ${isNarrator ? 'italic text-gray-300' : 'text-gray-100'}`} style={{ minHeight: '56px' }}>
          {typedText}
          <span className="inline-block w-2 h-4 bg-white ml-1 animate-ping"></span>
        </p>
      </div>
    </div>
  );
};

export default DialogueBox;