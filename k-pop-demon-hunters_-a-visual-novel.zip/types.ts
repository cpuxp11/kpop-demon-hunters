
export type SceneId = string;

export interface Character {
  id: string;
  name: string;
  sprites: {
    [emotion: string]: string; // e.g., 'neutral', 'sad', 'happy' -> image URL
  };
}

export interface Dialogue {
  character: string; // Character ID or 'Narrator'
  emotion?: string; // e.g. 'sad' to select sprite
  text: string;
  position?: 'left' | 'center' | 'right';
}

export interface Choice {
  text: string;
  nextScene: SceneId;
}

export interface Scene {
  background: string;
  dialogue: Dialogue[];
  choices?: Choice[];
  nextScene?: SceneId;
}

export type GameData = {
  [key: SceneId]: Scene;
};

export enum GameState {
  StartMenu,
  Playing,
  EndMenu,
}
